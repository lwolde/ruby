## Passenger: Ruby on Rails example app

This is a Ruby on Rails hello world example app for [the Passenger application server](https://www.phusionpassenger.com/).

The `master` branch contains the code without Passenger installed.

The `end_result` branch contains the code with Passenger installed.

Run `git diff origin/master..origin/end_result` to see what's different.
